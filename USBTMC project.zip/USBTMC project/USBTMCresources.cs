﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ivi.Visa.Interop;
using NationalInstruments.Visa;
using Ivi.Visa;
//using System.IO.Ports;
using System.IO;

namespace USBTMC_project
{
    class USBTMCresources
    {
       
    }
}
